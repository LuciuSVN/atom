module.exports = {
  activate: () => null,
  deactivate: () => null,
  handleURI: () => null,
}
