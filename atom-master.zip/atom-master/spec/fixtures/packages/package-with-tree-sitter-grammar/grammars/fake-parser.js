exports.isFakeTreeSitterParser = true
