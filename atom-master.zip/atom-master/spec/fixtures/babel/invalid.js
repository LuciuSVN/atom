'use 6to6';

module.exports = async function* hello() {}
